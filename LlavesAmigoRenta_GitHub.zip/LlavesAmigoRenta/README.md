# Llaves Amigo Renta — Android v1.0

Control de las llaves de la oficina identificadas por número: inventario, préstamos y devoluciones,
llaves atrasadas con aviso, historial de movimientos y exportación a Excel (.xlsx con hojas
"Inventario" e "Historial"). Pensada para un solo teléfono o tablet en la oficina.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
