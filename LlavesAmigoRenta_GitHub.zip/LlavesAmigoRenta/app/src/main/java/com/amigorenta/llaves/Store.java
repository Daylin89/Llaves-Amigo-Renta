package com.amigorenta.llaves;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("llaves", Context.MODE_PRIVATE); }

    static List<JSONObject> list(Context c, String key) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static void saveList(Context c, String key, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(key, a.toString()).apply();
    }

    static List<JSONObject> loadKeys(Context c) { return list(c, "keys"); }
    static void saveKeys(Context c, List<JSONObject> l) { saveList(c, "keys", l); }
    static List<JSONObject> loadLog(Context c) { return list(c, "log"); }
    static void saveLog(Context c, List<JSONObject> l) {
        while (l.size() > 8000) l.remove(0);
        saveList(c, "log", l);
    }

    static List<JSONObject> loadAvail(Context c) { return list(c, "avail"); }
    static void saveAvail(Context c, List<JSONObject> l) { saveList(c, "avail", l); }

    static int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).apply();
        return n;
    }

    // ---------- Ajustes ----------
    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static int lateHours(Context c) {
        try { return Integer.parseInt(get(c, "lateHours", "24")); } catch (Exception e) { return 24; }
    }

    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static Intent waIntent(Context c, String phone, String text) {
        String d = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        String url = "https://wa.me/" + d + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text));
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        String pkg = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pkg)) i.setPackage(pkg);
        return i;
    }

    static String waReminder(JSONObject k) {
        String prop = k.optString("property");
        return "Hola " + k.optString("holder") + ", le escribimos de Amigo Renta para recordarle devolver la llave #"
                + k.optString("num") + (prop.isEmpty() ? "" : " (" + prop + ")") + " a la oficina. ¡Gracias!";
    }

    // ---------- Fechas ----------
    static SimpleDateFormat f(String p) { SimpleDateFormat s = new SimpleDateFormat(p, Locale.US); s.setTimeZone(TZ); return s; }
    static SimpleDateFormat fe(String p) { SimpleDateFormat s = new SimpleDateFormat(p, ES); s.setTimeZone(TZ); return s; }
    static Calendar cal() { return Calendar.getInstance(TZ); }
    static String today() { return f("yyyy-MM-dd").format(new Date()); }
    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }
    static String shortDate(String iso) {
        try { return fe("d MMM").format(f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { return iso; }
    }
    static String dateTime(long ms) {
        if (ms <= 0) return "—";
        return cap(fe("EEE d MMM").format(new Date(ms))) + ", " + f("h:mm a").format(new Date(ms));
    }
    static long millisOf(String date, String time) {
        try { return f("yyyy-MM-dd HH:mm").parse(date + " " + time).getTime(); } catch (Exception e) { return 0; }
    }
    static String isoDay(long ms) { return f("yyyy-MM-dd").format(new Date(ms)); }
    static String excelDate(long ms) { return ms <= 0 ? "" : f("yyyy-MM-dd HH:mm").format(new Date(ms)); }

    static String duration(long ms) {
        long m = Math.max(0, ms / 60000);
        if (m < 60) return m + " min";
        long h = m / 60;
        if (h < 48) return h + " h" + (m % 60 > 0 && h < 10 ? " " + (m % 60) + " min" : "");
        return (h / 24) + " días";
    }

    static boolean isOut(JSONObject k) { return "prestada".equals(k.optString("status")); }

    static boolean isLate(Context c, JSONObject k) {
        if (!isOut(k)) return false;
        long now = System.currentTimeMillis();
        long due = k.optLong("dueAt");
        if (due > 0) return now > due;
        return now - k.optLong("outAt") > lateHours(c) * 3600000L;
    }

    // ---------- Avisos de llaves atrasadas ----------
    static void schedule(Context c, JSONObject k) {
        cancel(c, k);
        if (!isOut(k)) return;
        long due = k.optLong("dueAt");
        if (due <= 0) due = k.optLong("outAt") + lateHours(c) * 3600000L;
        if (due <= System.currentTimeMillis()) return;
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", "Llave #" + k.optString("num") + " sin devolver");
        i.putExtra("text", "La tiene " + k.optString("holder") + " desde " + dateTime(k.optLong("outAt"))
                + (k.optString("property").isEmpty() ? "" : " · " + k.optString("property")));
        i.putExtra("code", k.optInt("id"));
        if (!k.optString("holderPhone").isEmpty()) {
            i.putExtra("action", "Recordar a " + k.optString("holder"));
            i.putExtra("waPhone", k.optString("holderPhone"));
            i.putExtra("waText", waReminder(k));
        }
        PendingIntent pi = PendingIntent.getBroadcast(c, k.optInt("id"), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi);
    }

    static void cancel(Context c, JSONObject k) {
        PendingIntent pi = PendingIntent.getBroadcast(c, k.optInt("id"), new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
            pi.cancel();
        }
    }

    static void scheduleAll(Context c) {
        for (JSONObject k : loadKeys(c)) schedule(c, k);
    }
}
