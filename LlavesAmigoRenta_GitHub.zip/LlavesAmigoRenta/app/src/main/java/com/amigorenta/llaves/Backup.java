package com.amigorenta.llaves;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/** Copias de seguridad: guardar, enviar y restaurar todos los datos de la app. */
public class Backup {
    static final String PREFS = "llaves", APP = "llaves", LABEL = "Llaves Amigo Renta", PREFIX = "Llaves";
    static final int REQ_RESTORE = 7701, REQ_SAVE = 7702;
    static final String DIR = "Amigo Renta Respaldos";
    static String pendingJson;

    static SharedPreferences meta(Context c) { return c.getSharedPreferences("respaldo_meta", Context.MODE_PRIVATE); }

    static String toJson(Context c) throws Exception {
        JSONObject data = new JSONObject();
        for (Map.Entry<String, ?> e : c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getAll().entrySet()) {
            Object v = e.getValue();
            if (v == null || v instanceof java.util.Set) continue;
            String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Float ? "f" : "s";
            JSONObject o = new JSONObject();
            o.put("t", t);
            o.put("v", t.equals("s") ? v.toString() : v);
            data.put(e.getKey(), o);
        }
        JSONObject root = new JSONObject();
        root.put("app", APP);
        root.put("label", LABEL);
        root.put("created", System.currentTimeMillis());
        root.put("data", data);
        return root.toString();
    }

    static boolean fromJson(Context c, JSONObject root) throws Exception {
        JSONObject data = root.getJSONObject("data");
        SharedPreferences.Editor ed = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear();
        Iterator<String> it = data.keys();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject o = data.getJSONObject(k);
            String t = o.optString("t");
            if (t.equals("b")) ed.putBoolean(k, o.getBoolean("v"));
            else if (t.equals("i")) ed.putInt(k, o.getInt("v"));
            else if (t.equals("l")) ed.putLong(k, o.getLong("v"));
            else if (t.equals("f")) ed.putFloat(k, (float) o.getDouble("v"));
            else ed.putString(k, o.getString("v"));
        }
        return ed.commit();
    }

    static String stamp(long ms) { return new SimpleDateFormat("d MMM yyyy, h:mm a", new Locale("es")).format(new Date(ms)); }

    /** Guarda una copia en Descargas/Amigo Renta Respaldos. Devuelve el archivo o null. */
    static Uri saveFile(Context c, boolean auto) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            String json = toJson(c);
            String name = PREFIX + "_respaldo_" + new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date()) + ".json";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + DIR);
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(json.getBytes(StandardCharsets.UTF_8)); }
            meta(c).edit().putLong(APP + "_last", System.currentTimeMillis()).apply();
            cleanup(c);
            return u;
        } catch (Exception e) { return null; }
    }

    /** Deja solo las 6 copias más recientes de esta app. */
    static void cleanup(Context c) {
        try (Cursor cur = c.getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.MediaColumns._ID}, MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                new String[]{PREFIX + "_respaldo_%"}, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            int n = 0;
            while (cur != null && cur.moveToNext()) {
                n++;
                if (n > 6) {
                    try { c.getContentResolver().delete(ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cur.getLong(0)), null, null); }
                    catch (Exception ignored) { }
                }
            }
        } catch (Exception ignored) { }
    }

    /** Copia automática una vez por semana (se llama al abrir la app). */
    static void autoBackup(Context c) {
        try {
            long last = meta(c).getLong(APP + "_last", 0);
            if (System.currentTimeMillis() - last < 7L * 86400000L) return;
            if (c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getAll().isEmpty()) return;
            saveFile(c, true);
        } catch (Exception ignored) { }
    }

    static void toast(Context c, String s) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); }

    static void menu(Activity a) {
        long last = meta(a).getLong(APP + "_last", 0);
        String title = "💾 Copia de seguridad" + (last > 0 ? "\nÚltima: " + stamp(last) : "\nTodavía no hay copias");
        String[] items = {"📁 Guardar copia ahora (en Descargas)", "☁️ Guardar en OneDrive (info@amigorenta.com)", "📤 Enviar copia (correo, WhatsApp, Drive)", "♻️ Restaurar desde una copia"};
        new AlertDialog.Builder(a).setTitle(title).setItems(items, (dlg, w) -> {
            if (w == 0) {
                Uri u = saveFile(a, false);
                if (u != null) toast(a, "Copia guardada en Descargas → " + DIR + " ✅");
                else {
                    try {
                        pendingJson = toJson(a);
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_TITLE, PREFIX + "_respaldo.json");
                        a.startActivityForResult(i, REQ_SAVE);
                    } catch (Exception e) { toast(a, "No se pudo crear la copia"); }
                }
            } else if (w == 1) {
                Uri u = saveFile(a, false);
                if (u == null) { toast(a, "No se pudo crear la copia. Usa «Guardar copia ahora»."); return; }
                toOneDrive(a, one(u), "application/json");
            } else if (w == 2) {
                Uri u = saveFile(a, false);
                if (u == null) { toast(a, "No se pudo crear la copia. Usa «Guardar copia ahora»."); return; }
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.putExtra(Intent.EXTRA_SUBJECT, "Copia de seguridad · " + LABEL + " · " + stamp(System.currentTimeMillis()));
                i.putExtra(Intent.EXTRA_TEXT, "Copia de seguridad de " + LABEL + ". Para restaurarla: Más → Copia de seguridad → Restaurar.");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { a.startActivity(Intent.createChooser(i, "Enviar copia")); } catch (Exception e) { toast(a, "No hay app para enviar"); }
            } else {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { a.startActivityForResult(i, REQ_RESTORE); } catch (Exception e) { toast(a, "No se pudo abrir el selector de archivos"); }
            }
        }).show();
    }

    /** Devuelve true si el resultado era de una copia de seguridad. */
    static boolean onResult(Activity a, int rq, int rs, Intent data, Runnable afterRestore) {
        if (rq == REQ_SAVE) {
            if (rs == Activity.RESULT_OK && data != null && data.getData() != null && pendingJson != null) {
                try (OutputStream os = a.getContentResolver().openOutputStream(data.getData())) {
                    os.write(pendingJson.getBytes(StandardCharsets.UTF_8));
                    meta(a).edit().putLong(APP + "_last", System.currentTimeMillis()).apply();
                    toast(a, "Copia guardada ✅");
                } catch (Exception e) { toast(a, "No se pudo guardar la copia"); }
            }
            pendingJson = null;
            return true;
        }
        if (rq != REQ_RESTORE) return false;
        if (rs != Activity.RESULT_OK || data == null || data.getData() == null) return true;
        JSONObject root;
        try (InputStream in = a.getContentResolver().openInputStream(data.getData())) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            root = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
        } catch (Exception e) { toast(a, "Ese archivo no es una copia de seguridad válida"); return true; }
        if (!APP.equals(root.optString("app"))) {
            toast(a, "Esa copia es de «" + root.optString("label", "otra app") + "», no de " + LABEL);
            return true;
        }
        final JSONObject r = root;
        new AlertDialog.Builder(a)
                .setTitle("¿Restaurar esta copia?")
                .setMessage("Copia del " + stamp(root.optLong("created")) + ".\n\nSe reemplazarán TODOS los datos actuales de esta app por los de la copia.")
                .setPositiveButton("Restaurar", (dlg, w) -> {
                    try {
                        if (fromJson(a, r)) { toast(a, "Datos restaurados ✅"); afterRestore.run(); }
                        else toast(a, "No se pudo restaurar");
                    } catch (Exception e) { toast(a, "No se pudo restaurar: el archivo está dañado"); }
                })
                .setNegativeButton("Cancelar", null).show();
        return true;
    }

    // ---------- OneDrive (info@amigorenta.com) ----------
    static final String OD = "com.microsoft.skydrive";

    /** Abre la app OneDrive para subir los archivos (en el teléfono debe estar la cuenta info@amigorenta.com). */
    static void toOneDrive(Activity a, java.util.ArrayList<Uri> uris, String mime) {
        if (uris == null || uris.isEmpty()) { Toast.makeText(a, "No hay archivos para subir", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(uris.size() > 1 ? Intent.ACTION_SEND_MULTIPLE : Intent.ACTION_SEND);
        i.setType(mime);
        if (uris.size() > 1) i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        else i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.setPackage(OD);
        try {
            a.startActivity(i);
            Toast.makeText(a, "☁️ En OneDrive elige la carpeta (ej. «Amigo Renta») y toca Subir", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            new AlertDialog.Builder(a).setTitle("☁️ Falta la app OneDrive")
                    .setMessage("Instala OneDrive en este teléfono y entra con la cuenta info@amigorenta.com. Después vuelve a tocar «Guardar en OneDrive».")
                    .setPositiveButton("Instalar OneDrive", (d, w) -> {
                        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + OD))); }
                        catch (Exception e2) { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + OD))); }
                    }).setNegativeButton("Cancelar", null).show();
        }
    }

    static java.util.ArrayList<Uri> one(Uri u) { java.util.ArrayList<Uri> l = new java.util.ArrayList<>(); if (u != null) l.add(u); return l; }
}
