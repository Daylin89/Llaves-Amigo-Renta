package com.amigorenta.llaves;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, ORG = 0xFFEA580C;
    static final String[] TYPES = {"Puerta principal", "Habitación", "Buzón", "Garaje", "Lavandería",
            "Llave maestra", "Fob / tarjeta", "Candado", "Otra"};
    static final String[] PURPOSES = {"Mostrar propiedad", "Mantenimiento", "Inquilino nuevo", "Limpieza", "Inspección", "Otro"};
    static final String[] CODE_TYPES = {"Cerradura digital", "Caja de llaves (lockbox)", "Portón / garaje",
            "Edificio / intercomunicador", "Alarma", "Otro"};
    static final String[] ACCESS = {"Caja de llaves (lockbox)", "Código de puerta", "Llave en la oficina",
            "Conserje / administrador", "Inquilino abre", "Otro"};
    static final int REQ_EXPORT = 51, REQ_PHOTO = 61, REQ_VIDEO = 62, REQ_PICK = 63;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;

    interface Cb { void on(String s); }

    List<JSONObject> keys, log, avail;
    String availFilter = "Todas";
    int pendingAvail = -1;
    Uri pendingUri;
    String pendingMime;
    String pendingCat = "acceso";
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String filter = "Todas", search = "", logSearch = "";
    String expFrom, expTo;
    boolean pendingExport = false;

    // =====================================================================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        keys = Store.loadKeys(this);
        log = Store.loadLog(this);
        avail = Store.loadAvail(this);
        Calendar c = Store.cal();
        c.set(Calendar.DAY_OF_MONTH, 1);
        expFrom = Store.f("yyyy-MM-dd").format(c.getTime());
        expTo = Store.today();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        fab = tv("＋  Nueva llave", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        fab.setOnClickListener(v -> open(() -> keyForm(-1)));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        openTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!stack.isEmpty() && stack.size() == 1) stack.get(0).run();
    }

    // ============================ Navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::keysScreen);
        else if (k == 1) open(this::outScreen);
        else if (k == 2) open(this::availScreen);
        else if (k == 3) open(this::logScreen);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1);
            stack.get(stack.size() - 1).run();
        } else if (tabSel != 0) openTab(0);
        else finish();
    }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        t.addView(tv(title, 20, Color.WHITE, true));
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, boolean fabOn) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        fab.setVisibility(fabOn ? View.VISIBLE : View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"🔑", "Llaves"}, {"📤", "Prestadas"}, {"🏠", "Disponibles"}, {"🕘", "Historial"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    // ============================ Llaves ============================
    void keysScreen() {
        int out = 0, late = 0, codes = 0;
        for (JSONObject k : keys) { if (Store.isOut(k)) out++; if (Store.isLate(this, k)) late++; if (isCode(k)) codes++; }
        setHeader("Control de Llaves", (keys.size() - codes) + " llaves · " + codes + " códigos", "🔑", false);
        setFab("＋  Nueva llave", () -> open(() -> keyForm(-1)));
        LinearLayout p = vbox();
        LinearLayout row = hbox();
        row.setPadding(dp(10), dp(6), dp(10), 0);
        row.addView(stat("🔑", keys.size(), "Total", PRI2, 0xFFEAF1FF, "Todas"));
        row.addView(stat("🟢", keys.size() - codes - out, "En oficina", 0xFF15803D, 0xFFE3F6E8, "En oficina"));
        row.addView(stat("🟠", out, "Prestadas", 0xFFB45309, 0xFFFFF1DB, "Prestadas"));
        row.addView(stat("🔴", late, "Atrasadas", 0xFFB91C1C, 0xFFFDE6E6, "Atrasadas"));
        p.addView(row);

        EditText s = input("🔍  Buscar por número, dirección o persona", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(4), dp(10), dp(4));
        for (String o : new String[]{"Todas", "En oficina", "Prestadas", "Atrasadas", "Códigos"})
            chips.addView(chip(o, o.equals(filter), v -> { filter = o; keysScreen(); }));
        p.addView(hscroll(chips));

        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = search.trim().toLowerCase(Store.ES);
            List<JSONObject> r = new ArrayList<>();
            for (JSONObject k : keys) {
                if (filter.equals("En oficina") && (Store.isOut(k) || isCode(k))) continue;
                if (filter.equals("Códigos") && !isCode(k)) continue;
                if (filter.equals("Prestadas") && !Store.isOut(k)) continue;
                if (filter.equals("Atrasadas") && !Store.isLate(this, k)) continue;
                if (!q.isEmpty()) {
                    String num = k.optString("num").toLowerCase(Store.ES);
                    String hay = (k.optString("property") + " " + k.optString("unit") + " " + k.optString("type") + " "
                            + k.optString("holder")).toLowerCase(Store.ES);
                    if (!num.equals(q) && !num.startsWith(q) && !hay.contains(q)) continue;
                }
                r.add(k);
            }
            sortKeys(r);
            if (keys.isEmpty()) list.addView(empty("Todavía no hay llaves.\nToca «＋ Nueva llave» o ve a Más → Crear llaves en lote."));
            else if (r.isEmpty()) list.addView(empty("No se encontraron llaves"));
            for (JSONObject k : r) list.addView(keyRow(k));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, true);
    }

    View stat(String ic, int n, String label, int fg, int bg, String goFilter) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(0, dp(10), 0, dp(10));
        TextView i = tv(ic, 16, fg, false);
        TextView num = tv(String.valueOf(n), 22, fg, true);
        TextView l = tv(label, 11, fg, false);
        i.setGravity(Gravity.CENTER);
        num.setGravity(Gravity.CENTER);
        l.setGravity(Gravity.CENTER);
        l.setMaxLines(1);
        b.addView(i);
        b.addView(num);
        b.addView(l);
        b.setOnClickListener(v -> { filter = goFilter; keysScreen(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    int[] keyColors(JSONObject k) {
        if (isCode(k)) return new int[]{0xFF7C3AED, 0xFFF0E9FF};
        if (Store.isLate(this, k)) return new int[]{0xFFB91C1C, 0xFFFDE6E6};
        if (Store.isOut(k)) return new int[]{0xFFB45309, 0xFFFFF1DB};
        return new int[]{0xFF15803D, 0xFFE3F6E8};
    }

    String statusText(JSONObject k) {
        if (isCode(k)) return "🔢 Código de acceso";
        if (!Store.isOut(k)) return "🟢 En oficina";
        String who = k.optString("holder");
        String ago = Store.duration(System.currentTimeMillis() - k.optLong("outAt"));
        return (Store.isLate(this, k) ? "🔴 Atrasada · " : "🟠 ") + who + " · hace " + ago;
    }

    TextView badge(JSONObject k, int size) {
        int[] c = keyColors(k);
        TextView t = tv(k.optString("num"), size / 2.6f, c[0], true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        GradientDrawable g = round(c[1], 14);
        g.setStroke(dp(2), c[0]);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View keyRow(JSONObject k) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(badge(k, 56));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, dp(6), 0);
        String prop = k.optString("property");
        TextView pr = tv(prop.isEmpty() ? "Sin propiedad asignada" : prop, 15, prop.isEmpty() ? MUT : TXT, true);
        pr.setMaxLines(2);
        r.addView(pr);
        String sub = join(" · ", k.optString("unit"), k.optString("type"));
        if (!sub.isEmpty()) r.addView(tv(sub, 13, MUT, false));
        TextView st = tv(statusText(k), 13, keyColors(k)[0], true);
        st.setPadding(0, dp(3), 0, 0);
        r.addView(st);
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv("›", 22, MUT, false));
        final int id = k.optInt("id");
        c.setOnClickListener(v -> open(() -> keyDetail(id)));
        return c;
    }

    // ============================ Prestadas ============================
    void outScreen() {
        List<JSONObject> out = new ArrayList<>();
        for (JSONObject k : keys) if (Store.isOut(k)) out.add(k);
        Collections.sort(out, (x, y) -> Long.compare(x.optLong("outAt"), y.optLong("outAt")));
        int late = 0;
        for (JSONObject k : out) if (Store.isLate(this, k)) late++;
        setHeader("Llaves prestadas", out.size() + " fuera · " + late + " atrasadas", "📤", false);
        LinearLayout p = vbox();
        if (out.isEmpty()) p.addView(empty("🎉 Todas las llaves están en la oficina"));
        List<JSONObject> lateL = new ArrayList<>(), okL = new ArrayList<>();
        for (JSONObject k : out) { if (Store.isLate(this, k)) lateL.add(k); else okL.add(k); }
        if (!lateL.isEmpty()) {
            p.addView(sectionTitle("🔴 Atrasadas (" + lateL.size() + ")", null, null));
            for (JSONObject k : lateL) p.addView(outRow(k));
        }
        if (!okL.isEmpty()) {
            p.addView(sectionTitle("🟠 Prestadas (" + okL.size() + ")", null, null));
            for (JSONObject k : okL) p.addView(outRow(k));
        }
        show(scroll(p), true, false);
    }

    View outRow(JSONObject k) {
        LinearLayout c = card();
        LinearLayout top = hbox();
        top.addView(badge(k, 48));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, 0, 0);
        r.addView(tv(k.optString("holder"), 16, TXT, true));
        String prop = k.optString("property");
        if (!prop.isEmpty()) r.addView(tv(join(" · ", prop, k.optString("unit")), 13, MUT, false));
        r.addView(tv("Salió " + Store.dateTime(k.optLong("outAt")) + " · hace "
                + Store.duration(System.currentTimeMillis() - k.optLong("outAt")), 13, keyColors(k)[0], true));
        if (k.optLong("dueAt") > 0) r.addView(tv("Devolver antes de: " + Store.dateTime(k.optLong("dueAt")), 12, MUT, false));
        top.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(top);
        LinearLayout btns = hbox();
        btns.setPadding(0, dp(10), 0, 0);
        final int id = k.optInt("id");
        btns.addView(smallBtn("📥 Devuelta", GRN, v -> returnKey(id)), weightLp(1f));
        if (!k.optString("holderPhone").isEmpty())
            btns.addView(smallBtn("💬 Recordar", 0xFF0F766E, v -> launch(Store.waIntent(this, k.optString("holderPhone"), Store.waReminder(k)))), weightLp(1f));
        btns.addView(smallBtn("Ver", PRI2, v -> open(() -> keyDetail(id))), weightLp(0.6f));
        c.addView(btns);
        return c;
    }

    // ============================ Historial ============================
    void logScreen() {
        setHeader("Historial", log.size() + " movimientos", "🕘", false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar por número, dirección o persona", InputType.TYPE_CLASS_TEXT);
        s.setText(logSearch);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = logSearch.trim().toLowerCase(Store.ES);
            int shown = 0;
            String lastDay = "";
            for (int i = log.size() - 1; i >= 0 && shown < 300; i--) {
                JSONObject e = log.get(i);
                if (!q.isEmpty()) {
                    String hay = ("#" + e.optString("num") + " " + e.optString("num") + " " + e.optString("property") + " "
                            + e.optString("person")).toLowerCase(Store.ES);
                    if (!hay.contains(q)) continue;
                }
                String day = Store.isoDay(e.optLong("at"));
                if (!day.equals(lastDay)) {
                    lastDay = day;
                    list.addView(sectionTitle(day.equals(Store.today()) ? "Hoy" : Store.cap(Store.fe("EEEE d MMM yyyy").format(new java.util.Date(e.optLong("at")))), null, null));
                }
                list.addView(logRow(e, true));
                shown++;
            }
            if (shown == 0) list.addView(empty("No hay movimientos"));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable ed) { logSearch = ed.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, false);
    }

    View logRow(JSONObject e, boolean showKey) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        boolean lend = e.optString("action").equals("Préstamo");
        boolean shared = e.optString("action").equals("Código compartido");
        TextView ic = tv(shared ? "🔢" : lend ? "📤" : "📥", 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(shared ? 0xFFF0E9FF : lend ? 0xFFFFF1DB : 0xFFE3F6E8, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, 0, 0);
        String title = (shared ? "Código compartido con " : lend ? "Prestada a " : "Devuelta por ") + e.optString("person");
        if (showKey) title = (shared ? "Código #" : "Llave #") + e.optString("num") + " · " + title;
        r.addView(tv(title, 15, TXT, true));
        if (showKey && !e.optString("property").isEmpty()) r.addView(tv(e.optString("property"), 13, MUT, false));
        String extra = shared ? e.optString("phone") : lend ? e.optString("purpose") : (e.optLong("outAt") > 0 ? "Estuvo fuera " + Store.duration(e.optLong("at") - e.optLong("outAt")) : "");
        r.addView(tv(join(" · ", Store.f("h:mm a").format(new java.util.Date(e.optLong("at"))), extra), 13, shared ? 0xFF7C3AED : lend ? 0xFFB45309 : 0xFF15803D, true));
        if (!e.optString("notes").isEmpty()) r.addView(tv(e.optString("notes"), 13, MUT, false));
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        final int kid = e.optInt("keyId");
        c.setOnClickListener(v -> { if (findKey(kid) != null) open(() -> keyDetail(kid)); });
        return c;
    }

    // ============================ Detalle ============================
    void keyDetail(int id) {
        final JSONObject k = findKey(id);
        if (k == null) { goBack(); return; }
        final boolean code = isCode(k);
        setHeader((code ? "Código #" : "Llave #") + k.optString("num"), null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        LinearLayout top = hbox();
        top.addView(badge(k, 72));
        LinearLayout nv = vbox();
        nv.setPadding(dp(14), 0, 0, 0);
        String prop = k.optString("property");
        nv.addView(tv(prop.isEmpty() ? "Sin propiedad asignada" : prop, 17, TXT, true));
        String sub = join(" · ", k.optString("unit"), k.optString("type"));
        if (!sub.isEmpty()) nv.addView(tv(sub, 14, MUT, false));
        if (!code) {
            int copies = k.optInt("copies", 1);
            nv.addView(tv("🔑 " + copies + (copies == 1 ? " copia" : " copias"), 14, MUT, false));
        }
        top.addView(nv, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(top);
        if (!k.optString("notes").isEmpty()) { c.addView(divider()); c.addView(tv("📝 " + k.optString("notes"), 14, TXT, false)); }
        p.addView(c);

        LinearLayout st = card();
        int[] col = keyColors(k);
        st.setBackground(round(col[1], 16));
        if (code) {
            st.addView(tv("🔢  Acceso por código", 18, col[0], true));
            final String secret = k.optString("code");
            final TextView cv = tv(secret.isEmpty() ? "Sin código guardado" : mask(secret), 26, TXT, true);
            cv.setPadding(0, dp(8), 0, dp(4));
            st.addView(cv);
            if (!secret.isEmpty()) {
                TextView hint = tv("👁  Toca para ver / ocultar", 13, col[0], true);
                final boolean[] shown = {false};
                View.OnClickListener tg = v -> { shown[0] = !shown[0]; cv.setText(shown[0] ? secret : mask(secret)); };
                cv.setOnClickListener(tg);
                hint.setOnClickListener(tg);
                st.addView(hint);
            }
        } else if (!Store.isOut(k)) {
            st.addView(tv("🟢  En la oficina", 18, col[0], true));
            if (k.optLong("lastReturnAt") > 0)
                st.addView(tv("Devuelta " + Store.dateTime(k.optLong("lastReturnAt")), 14, TXT, false));
        } else {
            st.addView(tv((Store.isLate(this, k) ? "🔴  Atrasada · " : "🟠  Prestada a ") + k.optString("holder"), 18, col[0], true));
            if (!k.optString("holderPhone").isEmpty()) st.addView(tv("📞 " + k.optString("holderPhone"), 14, TXT, false));
            if (!k.optString("purpose").isEmpty()) st.addView(tv("🎯 " + k.optString("purpose"), 14, TXT, false));
            st.addView(tv("📤 Salió " + Store.dateTime(k.optLong("outAt")) + " (hace "
                    + Store.duration(System.currentTimeMillis() - k.optLong("outAt")) + ")", 14, TXT, false));
            if (k.optLong("dueAt") > 0) st.addView(tv("⏰ Devolver antes de " + Store.dateTime(k.optLong("dueAt")), 14, TXT, false));
            if (!k.optString("lendNotes").isEmpty()) st.addView(tv("📝 " + k.optString("lendNotes"), 14, TXT, false));
        }
        p.addView(st);

        if (code) {
            if (!k.optString("code").isEmpty()) {
                p.addView(button("💬  Compartir código por WhatsApp", 0xFF7C3AED, v -> shareCode(id)));
                LinearLayout b2 = hbox();
                b2.setPadding(dp(8), dp(4), dp(8), 0);
                b2.addView(outline("📋  Copiar código", 0xFF7C3AED, v -> {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Código", k.optString("code")));
                    toast("Código copiado");
                }), weightLp(1f));
                p.addView(b2);
            }
        } else if (!Store.isOut(k)) {
            p.addView(button("📤  Prestar llave", ORG, v -> open(() -> lendForm(id))));
        } else {
            p.addView(button("📥  Marcar como devuelta", GRN, v -> returnKey(id)));
            if (!k.optString("holderPhone").isEmpty()) {
                LinearLayout b2 = hbox();
                b2.setPadding(dp(8), dp(4), dp(8), 0);
                b2.addView(outline("💬  Recordar", 0xFF0F766E, v -> launch(Store.waIntent(this, k.optString("holderPhone"), Store.waReminder(k)))), weightLp(1f));
                b2.addView(outline("📞  Llamar", PRI2, v -> launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + k.optString("holderPhone"))))), weightLp(1f));
                p.addView(b2);
            }
        }

        p.addView(sectionTitle(code ? "A quién se ha compartido" : "Historial de esta llave", null, null));
        int n = 0;
        for (int i = log.size() - 1; i >= 0 && n < 40; i--) {
            JSONObject e = log.get(i);
            if (e.optInt("keyId") != id) continue;
            LinearLayout wrap = vbox();
            TextView d = tv(Store.dateTime(e.optLong("at")), 12, MUT, true);
            d.setPadding(dp(18), dp(4), 0, 0);
            wrap.addView(d);
            View row = logRow(e, false);
            row.setOnClickListener(null);
            wrap.addView(row);
            p.addView(wrap);
            n++;
        }
        if (n == 0) p.addView(empty(code ? "Todavía no se ha compartido" : "Esta llave todavía no se ha prestado"));

        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("✏️  Editar", PRI2, v -> open(() -> keyForm(id))), weightLp(1f));
        btns.addView(outline("🗑️  Eliminar", RED, v -> new AlertDialog.Builder(this)
                .setTitle("Eliminar #" + k.optString("num"))
                .setMessage("Se borra del inventario. El historial de movimientos se conserva.")
                .setPositiveButton("Eliminar", (dlg, w) -> {
                    Store.cancel(this, k);
                    keys.remove(k);
                    Store.saveKeys(this, keys);
                    toast("Eliminada del inventario");
                    goBack();
                })
                .setNegativeButton("Cancelar", null)
                .show()), weightLp(1f));
        p.addView(btns);
        show(scroll(p), false, false);
    }

    static boolean isCode(JSONObject k) { return "codigo".equals(k.optString("kind")); }

    static String mask(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && i < 12; i++) b.append("•");
        return b.toString();
    }

    void shareCode(int id) {
        final JSONObject k = findKey(id);
        if (k == null) return;
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText person = input("¿A quién se lo envías?", TXT_CAP);
        EditText phone = input("WhatsApp (opcional)", InputType.TYPE_CLASS_PHONE);
        box.addView(person);
        final Map<String, String> recent = recentPeople();
        if (!recent.isEmpty()) {
            LinearLayout rc = hbox();
            for (Map.Entry<String, String> en : recent.entrySet()) {
                final String nm = en.getKey(), ph = en.getValue();
                rc.addView(chip(nm, false, v -> { person.setText(nm); phone.setText(ph); }));
            }
            box.addView(hscroll(rc));
        }
        box.addView(phone);
        new AlertDialog.Builder(this)
                .setTitle("Compartir código #" + k.optString("num"))
                .setView(box)
                .setPositiveButton("Enviar", (dlg, w) -> {
                    String nm = person.getText().toString().trim();
                    String ph = phone.getText().toString().trim();
                    String where = join(" ", k.optString("property"), k.optString("unit"));
                    String msg = "Hola" + (nm.isEmpty() ? "" : " " + nm) + ", el código de acceso"
                            + (where.isEmpty() ? "" : " de " + where)
                            + (k.optString("type").isEmpty() ? "" : " (" + k.optString("type") + ")")
                            + " es: " + k.optString("code") + "\n\nAmigo Renta";
                    JSONObject e = new JSONObject();
                    put(e, "keyId", k.optInt("id"));
                    put(e, "num", k.optString("num"));
                    put(e, "property", k.optString("property"));
                    put(e, "unit", k.optString("unit"));
                    put(e, "action", "Código compartido");
                    put(e, "person", nm.isEmpty() ? "Sin nombre" : nm);
                    put(e, "phone", ph);
                    put(e, "at", System.currentTimeMillis());
                    log.add(e);
                    Store.saveLog(this, log);
                    launch(Store.waIntent(this, ph, msg));
                    stack.get(stack.size() - 1).run();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ============================ Formulario de llave ============================
    void keyForm(int id) {
        final JSONObject old = id < 0 ? null : findKey(id);
        setHeader(old == null ? "Nueva llave o código" : "Editar #" + old.optString("num"), null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText num = input("Ej. 12", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText prop = input("Ej. 801 E Broadway, Vancouver", TXT_CAP);
        EditText unit = input("Ej. Cuarto 3 / Suite 201", TXT_CAP);
        EditText copies = input("1", InputType.TYPE_CLASS_NUMBER);
        EditText codeF = input("Ej. 4589#", InputType.TYPE_CLASS_TEXT);
        EditText notes = input("Ej. Llave plateada con etiqueta azul", TXT_MULTI);
        TextView type = picker(TYPES, old != null && !isCode(old) ? old.optString("type") : TYPES[0]);
        TextView ctype = picker(CODE_TYPES, old != null && isCode(old) ? old.optString("type") : CODE_TYPES[0]);
        if (old != null) {
            num.setText(old.optString("num"));
            prop.setText(old.optString("property"));
            unit.setText(old.optString("unit"));
            copies.setText(String.valueOf(old.optInt("copies", 1)));
            codeF.setText(old.optString("code"));
            notes.setText(old.optString("notes"));
        } else {
            num.setText(suggestNum());
            copies.setText("1");
        }
        final boolean[] isC = {old != null && isCode(old)};
        if (old != null && Store.isOut(old)) isC[0] = false;

        final View copiesBox = labeled("Copias", copies);
        final View typeLbl = label("🏷️", "Tipo de llave", false);
        final View ctypeLbl = label("🏷️", "¿Qué abre el código?", false);
        final View codeLbl = label("🔢", "Código de acceso", true);
        final TextView kc1 = chip("🔑  Llave física", false, null);
        final TextView kc2 = chip("🔢  Código", false, null);
        final Runnable paint = () -> {
            styleChip(kc1, !isC[0]);
            styleChip(kc2, isC[0]);
            int kv = isC[0] ? View.GONE : View.VISIBLE, cvis = isC[0] ? View.VISIBLE : View.GONE;
            copiesBox.setVisibility(kv);
            typeLbl.setVisibility(kv);
            type.setVisibility(kv);
            ctypeLbl.setVisibility(cvis);
            ctype.setVisibility(cvis);
            codeLbl.setVisibility(cvis);
            codeF.setVisibility(cvis);
        };
        kc1.setOnClickListener(v -> { isC[0] = false; paint.run(); });
        kc2.setOnClickListener(v -> {
            if (old != null && Store.isOut(old)) { toast("Primero marca la llave como devuelta"); return; }
            isC[0] = true; paint.run();
        });
        LinearLayout kind = hbox();
        kind.addView(kc1);
        kind.addView(kc2);
        c.addView(label("❓", "¿Es llave física o código?", true));
        c.addView(kind);
        c.addView(label("#️⃣", "Número de identificación", true));
        c.addView(num);
        c.addView(label("🏠", "Propiedad (dirección)", false));
        c.addView(prop);
        LinearLayout uRow = hbox();
        uRow.setGravity(Gravity.TOP);
        uRow.addView(labeled("Unidad / cuarto", unit), new LinearLayout.LayoutParams(0, -2, 1.6f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
        cl.setMargins(dp(12), 0, 0, 0);
        uRow.addView(copiesBox, cl);
        c.addView(uRow);
        c.addView(typeLbl);
        c.addView(type);
        c.addView(ctypeLbl);
        c.addView(ctype);
        c.addView(codeLbl);
        c.addView(codeF);
        c.addView(label("📝", "Notas (opcional)", false));
        c.addView(notes);
        paint.run();

        p.addView(button("Guardar", PRI2, v -> {
            String n = num.getText().toString().trim().replace("#", "");
            if (n.isEmpty()) { toast("Escribe el número de identificación"); return; }
            if (isC[0] && codeF.getText().toString().trim().isEmpty()) { toast("Escribe el código de acceso"); return; }
            for (JSONObject x : keys)
                if (x != old && x.optString("num").equalsIgnoreCase(n)) { toast("Ya existe el #" + n); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) { put(o, "id", Store.nextId(this)); put(o, "status", "oficina"); }
            put(o, "num", n);
            put(o, "kind", isC[0] ? "codigo" : "llave");
            put(o, "property", prop.getText().toString().trim());
            put(o, "unit", unit.getText().toString().trim());
            int cp = 1;
            try { cp = Math.max(1, Integer.parseInt(copies.getText().toString().trim())); } catch (Exception e) { }
            put(o, "copies", cp);
            put(o, "type", isC[0] ? (String) ctype.getTag() : (String) type.getTag());
            put(o, "code", isC[0] ? codeF.getText().toString().trim() : "");
            put(o, "notes", notes.getText().toString().trim());
            if (old == null) keys.add(o);
            Store.saveKeys(this, keys);
            toast("#" + n + " guardado ✅");
            goBack();
        }));
        show(scroll(p), false, false);
    }

    String suggestNum() {
        int max = 0;
        for (JSONObject k : keys) max = Math.max(max, numVal(k.optString("num")));
        return String.valueOf(max + 1);
    }

    // ============================ Prestar / devolver ============================
    void lendForm(int id) {
        final JSONObject k = findKey(id);
        if (k == null) { goBack(); return; }
        setHeader("Prestar llave #" + k.optString("num"), k.optString("property"), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText person = input("Nombre de quien se la lleva", TXT_CAP);
        EditText phone = input("WhatsApp (opcional)", InputType.TYPE_CLASS_PHONE);

        final Map<String, String> recent = recentPeople();
        c.addView(label("👤", "¿Quién se la lleva?", true));
        c.addView(person);
        if (!recent.isEmpty()) {
            LinearLayout rc = hbox();
            for (Map.Entry<String, String> en : recent.entrySet()) {
                final String nm = en.getKey(), ph = en.getValue();
                rc.addView(chip(nm, false, v -> { person.setText(nm); phone.setText(ph); }));
            }
            c.addView(hscroll(rc));
        }
        c.addView(label("📞", "Teléfono", false));
        c.addView(phone);

        final String[] purpose = {PURPOSES[0]};
        final TextView[] pc = new TextView[PURPOSES.length];
        LinearLayout pr = hbox();
        for (int i = 0; i < PURPOSES.length; i++) {
            final int j = i;
            pc[i] = chip(PURPOSES[i], i == 0, v -> {
                purpose[0] = PURPOSES[j];
                for (int x = 0; x < pc.length; x++) styleChip(pc[x], x == j);
            });
            pr.addView(pc[i]);
        }
        c.addView(label("🎯", "Motivo", false));
        c.addView(hscroll(pr));

        final long[] due = {defaultDue()};
        final TextView dueTxt = tv("", 14, PRI2, true);
        dueTxt.setPadding(0, dp(6), 0, 0);
        final Runnable showDue = () -> dueTxt.setText(due[0] > 0 ? "⏰  Devolver antes de " + Store.dateTime(due[0]) : "⏰  Sin hora fija (se marca atrasada a las " + Store.lateHours(this) + " h)");
        String[] dl = {"En 2 horas", "Hoy 6 PM", "Mañana 10 AM", "Otra", "Sin hora"};
        final TextView[] dc = new TextView[dl.length];
        LinearLayout dr = hbox();
        for (int i = 0; i < dl.length; i++) {
            final int j = i;
            dc[i] = chip(dl[i], i == 1, v -> {
                for (int x = 0; x < dc.length; x++) styleChip(dc[x], x == j);
                if (j == 0) due[0] = System.currentTimeMillis() + 2 * 3600000L;
                else if (j == 1) due[0] = at(0, 18);
                else if (j == 2) due[0] = at(1, 10);
                else if (j == 4) due[0] = 0;
                else {
                    pickDate(Store.isoDay(due[0] > 0 ? due[0] : System.currentTimeMillis()), iso ->
                            pickTime("18:00", hm -> { due[0] = Store.millisOf(iso, hm); showDue.run(); }));
                }
                showDue.run();
            });
            dr.addView(dc[i]);
        }
        c.addView(label("⏰", "¿Cuándo la devuelve?", false));
        c.addView(hscroll(dr));
        c.addView(dueTxt);
        showDue.run();

        EditText notes = input("Ej. Se llevó también el fob del garaje", TXT_MULTI);
        c.addView(label("📝", "Notas (opcional)", false));
        c.addView(notes);

        p.addView(button("📤  Registrar préstamo", ORG, v -> {
            String nm = person.getText().toString().trim();
            if (nm.isEmpty()) { toast("Escribe quién se lleva la llave"); return; }
            long now = System.currentTimeMillis();
            put(k, "status", "prestada");
            put(k, "holder", nm);
            put(k, "holderPhone", phone.getText().toString().trim());
            put(k, "purpose", purpose[0]);
            put(k, "outAt", now);
            put(k, "dueAt", due[0]);
            put(k, "lendNotes", notes.getText().toString().trim());
            JSONObject e = new JSONObject();
            put(e, "keyId", k.optInt("id"));
            put(e, "num", k.optString("num"));
            put(e, "property", k.optString("property"));
            put(e, "unit", k.optString("unit"));
            put(e, "action", "Préstamo");
            put(e, "person", nm);
            put(e, "phone", phone.getText().toString().trim());
            put(e, "purpose", purpose[0]);
            put(e, "at", now);
            put(e, "dueAt", due[0]);
            put(e, "notes", notes.getText().toString().trim());
            log.add(e);
            Store.saveKeys(this, keys);
            Store.saveLog(this, log);
            Store.schedule(this, k);
            toast("Llave #" + k.optString("num") + " prestada a " + nm);
            goBack();
        }));
        show(scroll(p), false, false);
    }

    long defaultDue() {
        long six = at(0, 18);
        return six > System.currentTimeMillis() + 30 * 60000L ? six : at(1, 10);
    }

    long at(int plusDays, int hour) {
        Calendar c = Store.cal();
        c.add(Calendar.DAY_OF_MONTH, plusDays);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    void returnKey(int id) {
        final JSONObject k = findKey(id);
        if (k == null || !Store.isOut(k)) return;
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText notes = input("Nota (opcional): ej. devolvió también el fob", TXT_MULTI);
        box.addView(notes);
        new AlertDialog.Builder(this)
                .setTitle("¿Llave #" + k.optString("num") + " devuelta?")
                .setMessage("La tenía " + k.optString("holder") + " desde " + Store.dateTime(k.optLong("outAt")) + ".")
                .setView(box)
                .setPositiveButton("Sí, devuelta", (dlg, w) -> {
                    long now = System.currentTimeMillis();
                    JSONObject e = new JSONObject();
                    put(e, "keyId", k.optInt("id"));
                    put(e, "num", k.optString("num"));
                    put(e, "property", k.optString("property"));
                    put(e, "unit", k.optString("unit"));
                    put(e, "action", "Devolución");
                    put(e, "person", k.optString("holder"));
                    put(e, "phone", k.optString("holderPhone"));
                    put(e, "purpose", k.optString("purpose"));
                    put(e, "at", now);
                    put(e, "outAt", k.optLong("outAt"));
                    put(e, "notes", notes.getText().toString().trim());
                    log.add(e);
                    Store.cancel(this, k);
                    put(k, "status", "oficina");
                    put(k, "holder", "");
                    put(k, "holderPhone", "");
                    put(k, "purpose", "");
                    put(k, "outAt", 0);
                    put(k, "dueAt", 0);
                    put(k, "lendNotes", "");
                    put(k, "lastReturnAt", now);
                    Store.saveKeys(this, keys);
                    Store.saveLog(this, log);
                    toast("Llave #" + k.optString("num") + " de vuelta en la oficina ✅");
                    stack.get(stack.size() - 1).run();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    Map<String, String> recentPeople() {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        for (int i = log.size() - 1; i >= 0 && m.size() < 8; i--) {
            JSONObject e = log.get(i);
            String n = e.optString("person");
            if (!n.isEmpty() && !m.containsKey(n)) m.put(n, e.optString("phone"));
        }
        return m;
    }

    // ============================ Más ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("📊", "Exportar a Excel", "Inventario, historial y disponibles en .xlsx", v -> open(this::exportScreen)));
        c.addView(divider());
        c.addView(menuRow("🗂️", "Crear llaves en lote", "Ej. de la #1 a la #60 de una vez", v -> batchDialog()));
        c.addView(divider());
        c.addView(menuRow("⚙️", "Ajustes", "Horas para marcar atrasada y WhatsApp", v -> open(this::settings)));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Llaves Amigo Renta · versión 1.3", null));
        p.addView(c);
        show(scroll(p), true, false);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void batchDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText from = input("Desde #", InputType.TYPE_CLASS_NUMBER);
        EditText to = input("Hasta #", InputType.TYPE_CLASS_NUMBER);
        from.setText(suggestNum());
        box.addView(twoCols(from, to));
        TextView info = tv("Se crean solo los números que no existen. Después puedes asignar la propiedad a cada una.", 13, MUT, false);
        info.setPadding(0, dp(10), 0, 0);
        box.addView(info);
        new AlertDialog.Builder(this)
                .setTitle("Crear llaves en lote")
                .setView(box)
                .setPositiveButton("Crear", (dlg, w) -> {
                    int a, b;
                    try {
                        a = Integer.parseInt(from.getText().toString().trim());
                        b = Integer.parseInt(to.getText().toString().trim());
                    } catch (Exception e) { toast("Escribe los dos números"); return; }
                    if (b < a || b - a > 999) { toast("Revisa el rango (máximo 1000 llaves)"); return; }
                    int made = 0;
                    for (int n = a; n <= b; n++) {
                        boolean exists = false;
                        for (JSONObject x : keys) if (x.optString("num").equals(String.valueOf(n))) { exists = true; break; }
                        if (exists) continue;
                        JSONObject o = new JSONObject();
                        put(o, "id", Store.nextId(this));
                        put(o, "num", String.valueOf(n));
                        put(o, "status", "oficina");
                        put(o, "copies", 1);
                        put(o, "type", TYPES[0]);
                        keys.add(o);
                        made++;
                    }
                    Store.saveKeys(this, keys);
                    toast(made + " llaves creadas ✅");
                    openTab(0);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    void settings() {
        setHeader("Ajustes", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        final String[] hOpts = {"4", "8", "12", "24", "48", "72"};
        TextView hours = picker(hOpts, String.valueOf(Store.lateHours(this)));
        final String[] waOpts = {"WhatsApp Business", "WhatsApp normal"};
        TextView waApp = picker(waOpts, Store.get(this, "waApp", "business").equals("business") ? waOpts[0] : waOpts[1]);
        c.addView(label("⏰", "Marcar como atrasada después de (horas)", false));
        c.addView(hours);
        c.addView(tv("Se usa cuando el préstamo no tiene hora de devolución.", 12, MUT, false));
        c.addView(label("📲", "Abrir los recordatorios con", false));
        c.addView(waApp);
        TextView tz = tv("🕐  Las horas de la app están en horario de Vancouver.", 13, MUT, false);
        tz.setPadding(0, dp(16), 0, 0);
        c.addView(tz);
        p.addView(c);
        p.addView(button("Guardar ajustes", PRI2, v -> {
            Store.putS(this, "lateHours", (String) hours.getTag());
            Store.putS(this, "waApp", ((String) waApp.getTag()).equals(waOpts[0]) ? "business" : "normal");
            Store.scheduleAll(this);
            toast("Ajustes guardados ✅");
            goBack();
        }));
        show(scroll(p), false, false);
    }

    // ============================ Exportar a Excel ============================
    void exportScreen() {
        setHeader("Exportar a Excel", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView ic = tv("📊", 48, TXT, false);
        ic.setGravity(Gravity.CENTER);
        c.addView(ic);
        TextView t = tv("Archivo de Excel (.xlsx)", 20, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        TextView d = tv("Hoja «Inventario»: todas las llaves con su estado actual.\nHoja «Historial»: movimientos del período que elijas.\nHoja «Disponibles»: unidades y sus accesos.", 14, MUT, false);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, dp(6), 0, 0);
        c.addView(d);
        p.addView(c);
        p.addView(sectionTitle("Período del historial", null, null));
        p.addView(rangeCard(expFrom, expTo, iso -> { expFrom = iso; exportScreen(); }, iso -> { expTo = iso; exportScreen(); }));
        int n = 0;
        for (JSONObject e : log) { String day = Store.isoDay(e.optLong("at")); if (day.compareTo(expFrom) >= 0 && day.compareTo(expTo) <= 0) n++; }
        TextView cnt = tv(keys.size() + " llaves · " + n + " movimientos en el período", 15, TXT, true);
        cnt.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(cnt);
        p.addView(button("📊  Exportar Excel", GRN, v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            i.putExtra(Intent.EXTRA_TITLE, "llaves_amigo_renta_" + Store.today() + ".xlsx");
            pendingExport = true;
            try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
        }));
        show(scroll(p), false, false);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_PHOTO || rq == REQ_VIDEO || rq == REQ_PICK) { handleMediaResult(rq, rs, data); return; }
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null && pendingExport) {
            pendingExport = false;
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                writeXlsx(os);
                toast("Excel guardado ✅");
            } catch (Exception e) {
                toast("No se pudo guardar el archivo");
            }
        }
    }

    void writeXlsx(OutputStream os) throws Exception {
        List<List<Object>> inv = new ArrayList<>();
        inv.add(row("Número", "Clase", "Código", "Propiedad", "Unidad", "Tipo", "Copias", "Estado", "La tiene", "Teléfono", "Motivo",
                "Salió", "Devolver antes de", "Tiempo fuera", "Notas"));
        List<JSONObject> sorted = new ArrayList<>(keys);
        sortKeys(sorted);
        long now = System.currentTimeMillis();
        for (JSONObject k : sorted) {
            boolean out = Store.isOut(k);
            String estado = isCode(k) ? "Código" : out ? (Store.isLate(this, k) ? "Atrasada" : "Prestada") : "En oficina";
            Object num = k.optString("num").matches("\\d{1,9}") ? (Object) Integer.parseInt(k.optString("num")) : k.optString("num");
            inv.add(row(num, isCode(k) ? "Código" : "Llave", k.optString("code"), k.optString("property"), k.optString("unit"), k.optString("type"), k.optInt("copies", 1), estado,
                    out ? k.optString("holder") : "", out ? k.optString("holderPhone") : "", out ? k.optString("purpose") : "",
                    out ? Store.excelDate(k.optLong("outAt")) : "", out ? Store.excelDate(k.optLong("dueAt")) : "",
                    out ? Store.duration(now - k.optLong("outAt")) : "", k.optString("notes")));
        }
        List<List<Object>> his = new ArrayList<>();
        his.add(row("Fecha y hora", "Movimiento", "Número", "Propiedad", "Unidad", "Persona", "Teléfono", "Motivo", "Tiempo fuera", "Notas"));
        for (JSONObject e : log) {
            String day = Store.isoDay(e.optLong("at"));
            if (day.compareTo(expFrom) < 0 || day.compareTo(expTo) > 0) continue;
            boolean ret = e.optString("action").equals("Devolución");
            Object num = e.optString("num").matches("\\d{1,9}") ? (Object) Integer.parseInt(e.optString("num")) : e.optString("num");
            his.add(row(Store.excelDate(e.optLong("at")), e.optString("action"), num, e.optString("property"), e.optString("unit"),
                    e.optString("person"), e.optString("phone"), e.optString("purpose"),
                    ret && e.optLong("outAt") > 0 ? Store.duration(e.optLong("at") - e.optLong("outAt")) : "", e.optString("notes")));
        }
        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        zput(z, "[Content_Types].xml", hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "</Types>");
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>"
                + "<sheet name=\"Inventario\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"Historial\" sheetId=\"2\" r:id=\"rId2\"/><sheet name=\"Disponibles\" sheetId=\"3\" r:id=\"rId4\"/>"
                + "</sheets></workbook>");
        zput(z, "xl/_rels/workbook.xml.rels", hd + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"" + rel + "/worksheet\" Target=\"worksheets/sheet2.xml\"/>"
                + "<Relationship Id=\"rId4\" Type=\"" + rel + "/worksheet\" Target=\"worksheets/sheet3.xml\"/>"
                + "<Relationship Id=\"rId3\" Type=\"" + rel + "/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0D3B7A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        zput(z, "xl/worksheets/sheet1.xml", sheetXml(ns, inv, new int[]{9, 9, 12, 32, 16, 18, 8, 12, 20, 16, 18, 18, 18, 13, 30}));
        zput(z, "xl/worksheets/sheet2.xml", sheetXml(ns, his, new int[]{18, 13, 9, 32, 16, 20, 16, 18, 13, 30}));
        List<List<Object>> av = new ArrayList<>();
        av.add(row("Propiedad", "Unidad", "Precio", "Disponible desde", "Maquillada", "Cómo se entra", "Llave en el acceso", "Código",
                "Llave #", "Indicaciones del acceso", "Fotos habitación", "Fotos acceso"));
        for (JSONObject a : avail) {
            JSONArray md = a.optJSONArray("media");
            int fh = 0, fa = 0;
            if (md != null) for (int i = 0; i < md.length(); i++) {
                JSONObject m = md.optJSONObject(i);
                if (m == null) continue;
                if (catOf(m).equals("habitacion")) fh++; else fa++;
            }
            av.add(row(a.optString("property"), a.optString("unit"), price(a.optString("price")), a.optString("from"),
                    a.optBoolean("staged") ? "Sí" : "No", a.optString("method"), a.optBoolean("keyAtAccess") ? "Sí" : "No",
                    a.optString("code"), a.optString("keyNum"), a.optString("notes"), fh, fa));
        }
        zput(z, "xl/worksheets/sheet3.xml", sheetXml(ns, av, new int[]{32, 16, 10, 16, 12, 24, 16, 12, 9, 40, 14, 13}));
        z.finish();
    }

    static List<Object> row(Object... cells) {
        List<Object> r = new ArrayList<>();
        Collections.addAll(r, cells);
        return r;
    }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                Object v = row.get(c);
                String ref = colName(c) + (r + 1);
                String st = r == 0 ? " s=\"1\"" : "";
                if (v instanceof Integer) {
                    s.append("<c r=\"").append(ref).append("\"").append(st).append("><v>").append(v).append("</v></c>");
                } else {
                    String str = v == null ? "" : v.toString();
                    if (str.isEmpty() && r > 0) continue;
                    s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(st).append("><is><t xml:space=\"preserve\">")
                            .append(xml(str)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ Disponibles ============================
    void availScreen() {
        int at = 0, mq = 0;
        for (JSONObject a : avail) { if (a.optBoolean("keyAtAccess")) at++; if (a.optBoolean("staged")) mq++; }
        setHeader("Disponibles", avail.size() + " unidades · " + at + " con llave · " + mq + " maquilladas", "🏠", false);
        setFab("＋  Agregar disponible", () -> open(() -> availForm(-1)));
        LinearLayout p = vbox();
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(8), dp(10), dp(4));
        for (String o : new String[]{"Todas", "Llave en el acceso", "Sin llave en el acceso", "Maquilladas", "Sin maquillar"})
            chips.addView(chip(o, o.equals(availFilter), v -> { availFilter = o; availScreen(); }));
        p.addView(hscroll(chips));
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject a : avail) {
            if (availFilter.equals("Llave en el acceso") && !a.optBoolean("keyAtAccess")) continue;
            if (availFilter.equals("Sin llave en el acceso") && a.optBoolean("keyAtAccess")) continue;
            if (availFilter.equals("Maquilladas") && !a.optBoolean("staged")) continue;
            if (availFilter.equals("Sin maquillar") && a.optBoolean("staged")) continue;
            r.add(a);
        }
        Collections.sort(r, (x, y) -> (x.optString("property") + x.optString("unit")).compareToIgnoreCase(y.optString("property") + y.optString("unit")));
        if (avail.isEmpty()) p.addView(empty("Agrega aquí las unidades disponibles, cómo se entra y fotos o videos del acceso."));
        else if (r.isEmpty()) p.addView(empty("No hay unidades con este filtro"));
        for (JSONObject a : r) p.addView(availRow(a));
        show(scroll(p), true, true);
    }

    View availRow(JSONObject a) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        JSONArray media = a.optJSONArray("media");
        FrameLayout th = new FrameLayout(this);
        th.setBackground(round(0xFFEAF1FF, 12));
        th.setClipToOutline(true);
        TextView ph = tv("🏠", 26, PRI2, false);
        ph.setGravity(Gravity.CENTER);
        th.addView(ph, new FrameLayout.LayoutParams(-1, -1));
        JSONObject m = firstMedia(media, "habitacion");
        if (m == null) m = firstMedia(media, "acceso");
        if (m != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            loadThumb(iv, Uri.parse(m.optString("uri")), m.optString("mime"));
        }
        c.addView(th, new LinearLayout.LayoutParams(dp(66), dp(66)));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, dp(6), 0);
        TextView pr = tv(a.optString("property"), 15, TXT, true);
        pr.setMaxLines(2);
        r.addView(pr);
        String sub = join(" · ", a.optString("unit"), price(a.optString("price")),
                a.optString("from").isEmpty() ? "" : "desde " + Store.shortDate(a.optString("from")));
        if (!sub.isEmpty()) r.addView(tv(sub, 13, MUT, false));
        boolean in = a.optBoolean("keyAtAccess");
        TextView pill = tv(in ? "🔓 Llave en el acceso" : "🔒 Sin llave en el acceso", 12, in ? 0xFF15803D : 0xFFB91C1C, true);
        pill.setBackground(round(in ? 0xFFE3F6E8 : 0xFFFDE6E6, 20));
        pill.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout pl = hbox();
        pl.setPadding(0, dp(5), 0, 0);
        pl.addView(pill);
        int nm = media == null ? 0 : media.length();
        if (nm > 0) { TextView mc = tv("  📸 " + nm, 12, MUT, true); pl.addView(mc); }
        r.addView(pl);
        boolean mk = a.optBoolean("staged");
        TextView mp = tv(mk ? "✨ Maquillada" : "🧹 Sin maquillar", 12, mk ? 0xFF7C3AED : 0xFFB45309, true);
        mp.setBackground(round(mk ? 0xFFF0E9FF : 0xFFFFF1DB, 20));
        mp.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout ml = hbox();
        ml.setPadding(0, dp(4), 0, 0);
        ml.addView(mp);
        r.addView(ml);
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv("›", 22, MUT, false));
        final int id = a.optInt("id");
        c.setOnClickListener(v -> open(() -> availDetail(id)));
        return c;
    }

    static String price(String p) {
        p = p == null ? "" : p.trim();
        if (p.isEmpty()) return "";
        return p.startsWith("$") ? p : "$" + p;
    }

    void availForm(int id) {
        final JSONObject old = id < 0 ? null : findAvail(id);
        setHeader(old == null ? "Agregar disponible" : "Editar disponible", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText prop = input("Ej. 801 E Broadway, Vancouver", TXT_CAP);
        EditText unit = input("Ej. Cuarto 3", TXT_CAP);
        EditText priceF = input("Ej. 950", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText codeF = input("Ej. 2580 (si aplica)", InputType.TYPE_CLASS_TEXT);
        EditText keyNum = input("Ej. 12 (opcional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText notes = input("Ej. Caja negra detrás de la reja, lado izquierdo", TXT_MULTI);
        notes.setMinLines(3);
        TextView method = picker(ACCESS, old != null ? old.optString("method") : ACCESS[0]);
        final String[] from = {old != null && !old.optString("from").isEmpty() ? old.optString("from") : Store.today()};
        final TextView fromF = field("📅  " + Store.shortDate(from[0]) + " " + from[0].substring(0, 4));
        fromF.setOnClickListener(v -> pickDate(from[0], iso -> { from[0] = iso; fromF.setText("📅  " + Store.shortDate(iso) + " " + iso.substring(0, 4)); }));
        Switch atAccess = new Switch(this);
        atAccess.setText("🔓  La llave está en el acceso");
        atAccess.setTextSize(16);
        atAccess.setTextColor(TXT);
        atAccess.setPadding(0, dp(16), 0, dp(4));
        Switch staged = new Switch(this);
        staged.setText("✨  La habitación está maquillada");
        staged.setTextSize(16);
        staged.setTextColor(TXT);
        staged.setPadding(0, dp(12), 0, dp(4));
        if (old != null) {
            prop.setText(old.optString("property"));
            unit.setText(old.optString("unit"));
            priceF.setText(old.optString("price"));
            codeF.setText(old.optString("code"));
            keyNum.setText(old.optString("keyNum"));
            notes.setText(old.optString("notes"));
            atAccess.setChecked(old.optBoolean("keyAtAccess"));
            staged.setChecked(old.optBoolean("staged"));
        }
        c.addView(label("🏠", "Propiedad (dirección)", true));
        c.addView(prop);
        c.addView(twoCols(labeled("Unidad / cuarto", unit), labeled("Precio mensual", priceF)));
        c.addView(labeled("Disponible desde", fromF));
        c.addView(label("🚪", "¿Cómo se entra?", false));
        c.addView(method);
        c.addView(atAccess);
        c.addView(staged);
        c.addView(twoCols(labeled("Código (si aplica)", codeF), labeled("Llave # (si aplica)", keyNum)));
        c.addView(label("📍", "¿Dónde está el acceso? Indicaciones", false));
        c.addView(notes);
        TextView tip = tv("📸 Las fotos de la habitación y del acceso se agregan en la siguiente pantalla.", 13, MUT, false);
        tip.setPadding(0, dp(12), 0, 0);
        c.addView(tip);

        p.addView(button("Guardar", PRI2, v -> {
            String pr = prop.getText().toString().trim();
            if (pr.isEmpty()) { toast("Escribe la dirección de la propiedad"); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) { put(o, "id", Store.nextId(this)); put(o, "media", new JSONArray()); }
            put(o, "property", pr);
            put(o, "unit", unit.getText().toString().trim());
            put(o, "price", priceF.getText().toString().trim());
            put(o, "from", from[0]);
            put(o, "method", (String) method.getTag());
            if (old == null || old.optBoolean("keyAtAccess") != atAccess.isChecked()) put(o, "accessChangedAt", System.currentTimeMillis());
            if (old == null || old.optBoolean("staged") != staged.isChecked()) put(o, "stagedChangedAt", System.currentTimeMillis());
            put(o, "keyAtAccess", atAccess.isChecked());
            put(o, "staged", staged.isChecked());
            put(o, "code", codeF.getText().toString().trim());
            put(o, "keyNum", keyNum.getText().toString().trim().replace("#", ""));
            put(o, "notes", notes.getText().toString().trim());
            put(o, "updated", System.currentTimeMillis());
            if (old == null) avail.add(o);
            Store.saveAvail(this, avail);
            toast("Guardado ✅");
            if (old == null) {
                stack.remove(stack.size() - 1);
                final int nid = o.optInt("id");
                open(() -> availDetail(nid));
            } else goBack();
        }));
        show(scroll(p), false, false);
    }

    void availDetail(int id) {
        final JSONObject a = findAvail(id);
        if (a == null) { goBack(); return; }
        setHeader(a.optString("property"), a.optString("unit").isEmpty() ? null : a.optString("unit"), null, true);
        LinearLayout p = vbox();

        LinearLayout c = card();
        c.addView(tv("🏠  " + a.optString("property"), 17, TXT, true));
        String sub = join(" · ", a.optString("unit"), price(a.optString("price")) + (a.optString("price").isEmpty() ? "" : "/mes"));
        if (!sub.isEmpty()) c.addView(tv(sub, 15, TXT, false));
        if (!a.optString("from").isEmpty()) c.addView(tv("📅  Disponible desde " + Store.shortDate(a.optString("from")) + " " + a.optString("from").substring(0, 4), 14, MUT, false));
        p.addView(c);

        final boolean in = a.optBoolean("keyAtAccess");
        LinearLayout tg = card();
        tg.setOrientation(LinearLayout.HORIZONTAL);
        tg.setGravity(Gravity.CENTER_VERTICAL);
        tg.setBackground(round(in ? 0xFFE3F6E8 : 0xFFFDE6E6, 16));
        LinearLayout tt = vbox();
        tt.addView(tv(in ? "🔓  La llave SÍ está en el acceso" : "🔒  La llave NO está en el acceso", 17, in ? 0xFF15803D : 0xFFB91C1C, true));
        if (a.optLong("accessChangedAt") > 0) tt.addView(tv("Actualizado " + Store.dateTime(a.optLong("accessChangedAt")), 13, TXT, false));
        tg.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView sw = tv("Cambiar", 14, in ? 0xFF15803D : 0xFFB91C1C, true);
        sw.setBackground(roundStroke(Color.WHITE, 20, in ? 0xFF15803D : 0xFFB91C1C));
        sw.setPadding(dp(14), dp(8), dp(14), dp(8));
        tg.addView(sw);
        tg.setOnClickListener(v -> {
            put(a, "keyAtAccess", !in);
            put(a, "accessChangedAt", System.currentTimeMillis());
            Store.saveAvail(this, avail);
            availDetail(id);
        });
        p.addView(tg);

        final boolean mk = a.optBoolean("staged");
        LinearLayout sg = card();
        sg.setOrientation(LinearLayout.HORIZONTAL);
        sg.setGravity(Gravity.CENTER_VERTICAL);
        int mkCol = mk ? 0xFF7C3AED : 0xFFB45309;
        sg.setBackground(round(mk ? 0xFFF0E9FF : 0xFFFFF1DB, 16));
        LinearLayout st2 = vbox();
        st2.addView(tv(mk ? "✨  Habitación maquillada" : "🧹  Habitación sin maquillar", 17, mkCol, true));
        if (a.optLong("stagedChangedAt") > 0) st2.addView(tv("Actualizado " + Store.dateTime(a.optLong("stagedChangedAt")), 13, TXT, false));
        sg.addView(st2, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView sw2 = tv("Cambiar", 14, mkCol, true);
        sw2.setBackground(roundStroke(Color.WHITE, 20, mkCol));
        sw2.setPadding(dp(14), dp(8), dp(14), dp(8));
        sg.addView(sw2);
        sg.setOnClickListener(v -> {
            put(a, "staged", !mk);
            put(a, "stagedChangedAt", System.currentTimeMillis());
            Store.saveAvail(this, avail);
            availDetail(id);
        });
        p.addView(sg);

        LinearLayout ac = card();
        ac.addView(tv("🚪  " + (a.optString("method").isEmpty() ? "Acceso" : a.optString("method")), 16, TXT, true));
        final String code = a.optString("code");
        if (!code.isEmpty()) {
            final TextView cv = tv("🔢  Código: " + mask(code) + "   👁", 16, 0xFF7C3AED, true);
            cv.setPadding(0, dp(8), 0, 0);
            final boolean[] shown = {false};
            cv.setOnClickListener(v -> { shown[0] = !shown[0]; cv.setText("🔢  Código: " + (shown[0] ? code : mask(code)) + "   👁"); });
            ac.addView(cv);
        }
        if (!a.optString("keyNum").isEmpty()) {
            TextView kn = tv("🔑  Llave #" + a.optString("keyNum") + "  ›", 15, PRI2, true);
            kn.setPadding(0, dp(8), 0, 0);
            kn.setOnClickListener(v -> {
                for (JSONObject k : keys) if (k.optString("num").equalsIgnoreCase(a.optString("keyNum"))) {
                    final int kid = k.optInt("id");
                    open(() -> keyDetail(kid));
                    return;
                }
                toast("No hay una llave #" + a.optString("keyNum") + " en el inventario");
            });
            ac.addView(kn);
        }
        if (!a.optString("notes").isEmpty()) {
            TextView nt = tv("📍  " + a.optString("notes"), 15, TXT, false);
            nt.setPadding(0, dp(8), 0, 0);
            ac.addView(nt);
        }
        p.addView(ac);

        mediaSection(p, a, id, "habitacion", "🛏️ Fotos de la habitación");
        mediaSection(p, a, id, "acceso", "🚪 Fotos y videos del acceso");

        p.addView(button("💬  Compartir acceso (para el equipo)", GRN, v -> shareAccess(a, true)));
        LinearLayout sb = hbox();
        sb.setPadding(dp(8), dp(4), dp(8), 0);
        sb.addView(outline("📤  Enviar fotos de la habitación al cliente", 0xFF7C3AED, v -> shareAccess(a, false)), weightLp(1f));
        p.addView(sb);
        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("📍  Mapa", 0xFF0F766E, v -> launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("property")))))), weightLp(1f));
        btns.addView(outline("✏️  Editar", PRI2, v -> open(() -> availForm(id))), weightLp(1f));
        btns.addView(outline("🗑️", RED, v -> new AlertDialog.Builder(this)
                .setTitle("Eliminar esta unidad")
                .setMessage("Se quita de Disponibles (por ejemplo, porque ya se rentó). Las fotos siguen en la galería.")
                .setPositiveButton("Eliminar", (dlg, w) -> { avail.remove(a); Store.saveAvail(this, avail); goBack(); })
                .setNegativeButton("Cancelar", null).show()), weightLp(0.5f));
        p.addView(btns);
        show(scroll(p), false, false);
    }

    void shareAccess(JSONObject a, boolean team) {
        StringBuilder t = new StringBuilder("🏠 ").append(a.optString("property"));
        if (!a.optString("unit").isEmpty()) t.append(" · ").append(a.optString("unit"));
        if (!a.optString("price").isEmpty()) t.append("\n💲 ").append(price(a.optString("price"))).append("/mes");
        if (!a.optString("from").isEmpty()) t.append("\n📅 Disponible desde ").append(Store.shortDate(a.optString("from")));
        if (team) {
            if (!a.optString("method").isEmpty()) t.append("\n🚪 Acceso: ").append(a.optString("method"));
            t.append(a.optBoolean("keyAtAccess") ? "\n✅ La llave está en el acceso" : "\n⚠️ La llave NO está en el acceso");
            t.append(a.optBoolean("staged") ? "\n✨ Habitación maquillada" : "\n🧹 Habitación sin maquillar");
            if (!a.optString("code").isEmpty()) t.append("\n🔢 Código: ").append(a.optString("code"));
            if (!a.optString("notes").isEmpty()) t.append("\n📍 ").append(a.optString("notes"));
        }
        t.append("\n\nAmigo Renta");
        ArrayList<Uri> uris = new ArrayList<>();
        String mime = null;
        JSONArray media = a.optJSONArray("media");
        if (media != null) for (int i = 0; i < media.length(); i++) {
            JSONObject m = media.optJSONObject(i);
            if (m == null) continue;
            if (!catOf(m).equals(team ? "acceso" : "habitacion")) continue;
            uris.add(Uri.parse(m.optString("uri")));
            mime = mime == null ? m.optString("mime") : (mime.equals(m.optString("mime")) ? mime : "*/*");
        }
        Intent i;
        if (uris.isEmpty()) { i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); }
        else if (uris.size() == 1) { i = new Intent(Intent.ACTION_SEND); i.setType(mime); i.putExtra(Intent.EXTRA_STREAM, uris.get(0)); }
        else { i = new Intent(Intent.ACTION_SEND_MULTIPLE); i.setType(mime); i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris); }
        i.putExtra(Intent.EXTRA_TEXT, t.toString());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        launch(Intent.createChooser(i, team ? "Compartir acceso" : "Enviar fotos de la habitación"));
    }

    // ---------- Cámara y galería ----------
    void capture(int availId, boolean video, String cat) {
        pendingCat = cat;
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a tocar el botón");
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, cat + "_" + System.currentTimeMillis() + (video ? ".mp4" : ".jpg"));
        cv.put(MediaStore.MediaColumns.MIME_TYPE, video ? "video/mp4" : "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + (cat.equals("habitacion") ? "/Amigo Renta Habitaciones" : "/Amigo Renta Accesos"));
        Uri u = null;
        try {
            u = getContentResolver().insert(video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        } catch (Exception e) { }
        if (u == null) { toast("No se pudo preparar la cámara"); return; }
        pendingAvail = availId;
        pendingUri = u;
        pendingMime = video ? "video/mp4" : "image/jpeg";
        Intent i = new Intent(video ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, u);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(i, video ? REQ_VIDEO : REQ_PHOTO); }
        catch (Exception e) {
            toast("No hay app de cámara");
            try { getContentResolver().delete(u, null, null); } catch (Exception x) { }
        }
    }

    void pickMedia(int availId, String cat) {
        pendingAvail = availId;
        pendingCat = cat;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_PICK); } catch (Exception e) { toast("No se pudo abrir la galería"); }
    }

    void addMedia(int availId, Uri u, String mime) {
        JSONObject a = findAvail(availId);
        if (a == null || u == null) return;
        JSONArray m = a.optJSONArray("media");
        if (m == null) { m = new JSONArray(); put(a, "media", m); }
        JSONObject o = new JSONObject();
        put(o, "uri", u.toString());
        put(o, "mime", mime == null ? "image/jpeg" : mime);
        put(o, "cat", pendingCat);
        put(o, "at", System.currentTimeMillis());
        m.put(o);
        Store.saveAvail(this, avail);
    }

    void handleMediaResult(int rq, int rs, Intent data) {
        if (rq == REQ_PHOTO || rq == REQ_VIDEO) {
            if (rs == RESULT_OK && pendingUri != null) {
                Uri u = pendingUri;
                if (rq == REQ_VIDEO && data != null && data.getData() != null && !data.getData().equals(pendingUri) && isEmptyUri(pendingUri)) {
                    try { getContentResolver().delete(pendingUri, null, null); } catch (Exception e) { }
                    u = data.getData();
                }
                addMedia(pendingAvail, u, pendingMime);
                toast(rq == REQ_VIDEO ? "Video guardado ✅" : "Foto guardada ✅");
            } else if (pendingUri != null) {
                try { getContentResolver().delete(pendingUri, null, null); } catch (Exception e) { }
            }
            pendingUri = null;
        } else if (rq == REQ_PICK && rs == RESULT_OK && data != null) {
            ArrayList<Uri> list = new ArrayList<>();
            if (data.getClipData() != null)
                for (int i = 0; i < data.getClipData().getItemCount(); i++) list.add(data.getClipData().getItemAt(i).getUri());
            else if (data.getData() != null) list.add(data.getData());
            for (Uri u : list) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
                addMedia(pendingAvail, u, getContentResolver().getType(u));
            }
            if (!list.isEmpty()) toast(list.size() + (list.size() == 1 ? " archivo agregado ✅" : " archivos agregados ✅"));
        }
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
    }

    boolean isEmptyUri(Uri u) {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            return in == null || in.read() == -1;
        } catch (Exception e) { return true; }
    }

    void loadThumb(ImageView iv, Uri u, String mime) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                if (mime != null && mime.startsWith("video")) {
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    r.setDataSource(this, u);
                    b = r.getFrameAtTime(1000000);
                    try { r.release(); } catch (Exception e) { }
                } else {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                    int s = 1;
                    while (o.outWidth / (s * 2) >= 300 && o.outHeight / (s * 2) >= 300) s *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = s;
                    try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
                    int rot = 0;
                    try (InputStream in = getContentResolver().openInputStream(u)) {
                        int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                        rot = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                    } catch (Exception e) { }
                    if (b != null && rot != 0) {
                        Matrix mx = new Matrix();
                        mx.postRotate(rot);
                        b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mx, true);
                    }
                }
                if (b != null && b.getWidth() > 500) {
                    int h = Math.max(1, b.getHeight() * 500 / b.getWidth());
                    b = Bitmap.createScaledBitmap(b, 500, h, true);
                }
            } catch (Exception e) { b = null; }
            final Bitmap fb = b;
            runOnUiThread(() -> { if (fb != null) iv.setImageBitmap(fb); });
        }).start();
    }

    static String catOf(JSONObject m) {
        String c = m.optString("cat");
        return c.isEmpty() ? "acceso" : c;
    }

    static JSONObject firstMedia(JSONArray media, String cat) {
        if (media == null) return null;
        for (int i = 0; i < media.length(); i++) {
            JSONObject m = media.optJSONObject(i);
            if (m != null && catOf(m).equals(cat)) return m;
        }
        return null;
    }

    void mediaSection(LinearLayout p, JSONObject a, int id, String cat, String title) {
        final JSONArray media = a.optJSONArray("media");
        ArrayList<Integer> idxs = new ArrayList<>();
        if (media != null) for (int i = 0; i < media.length(); i++) {
            JSONObject m = media.optJSONObject(i);
            if (m != null && catOf(m).equals(cat)) idxs.add(i);
        }
        p.addView(sectionTitle(title + " (" + idxs.size() + ")", null, null));
        LinearLayout mb = hbox();
        mb.setPadding(dp(10), 0, dp(10), 0);
        mb.addView(action("📷", "Tomar foto", PRI2, 0xFFEAF1FF, v -> capture(id, false, cat)));
        mb.addView(action("🎥", "Grabar video", 0xFFB91C1C, 0xFFFDE6E6, v -> capture(id, true, cat)));
        mb.addView(action("🖼️", "De la galería", 0xFF15803D, 0xFFE3F6E8, v -> pickMedia(id, cat)));
        p.addView(mb);
        if (idxs.isEmpty()) { p.addView(empty("Todavía no hay fotos ni videos")); return; }
        LinearLayout grid = vbox();
        grid.setPadding(dp(10), dp(6), dp(10), 0);
        LinearLayout row = null;
        for (int n = 0; n < idxs.size(); n++) {
            if (n % 3 == 0) { row = hbox(); grid.addView(row); }
            final int idx = idxs.get(n);
            final JSONObject m = media.optJSONObject(idx);
            final Uri u = Uri.parse(m.optString("uri"));
            FrameLayout cell = new FrameLayout(this);
            cell.setBackground(round(0xFFE1E7EF, 12));
            cell.setClipToOutline(true);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cell.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            if (m.optString("mime").startsWith("video")) {
                TextView play = tv("▶", 30, Color.WHITE, true);
                play.setGravity(Gravity.CENTER);
                play.setShadowLayer(8, 0, 0, Color.BLACK);
                cell.addView(play, new FrameLayout.LayoutParams(-1, -1));
            }
            loadThumb(iv, u, m.optString("mime"));
            cell.setOnClickListener(v -> {
                Intent vi = new Intent(Intent.ACTION_VIEW);
                vi.setDataAndType(u, m.optString("mime"));
                vi.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                launch(vi);
            });
            cell.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("¿Quitar este archivo?")
                        .setMessage("Se quita de esta unidad. El archivo sigue en la galería del teléfono.")
                        .setPositiveButton("Quitar", (dlg, w) -> {
                            JSONArray nmArr = new JSONArray();
                            for (int j = 0; j < media.length(); j++) if (j != idx) nmArr.put(media.opt(j));
                            put(a, "media", nmArr);
                            Store.saveAvail(this, avail);
                            availDetail(id);
                        })
                        .setNegativeButton("Cancelar", null).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(110), 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            row.addView(cell, lp);
        }
        if (row != null) while (row.getChildCount() < 3) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(110), 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            row.addView(new View(this), lp);
        }
        p.addView(grid);
        TextView hint = tv("Toca para ver · mantén presionado para quitar", 12, MUT, false);
        hint.setPadding(dp(18), dp(4), 0, 0);
        p.addView(hint);
    }

    JSONObject findAvail(int id) {
        for (JSONObject a : avail) if (a.optInt("id") == id) return a;
        return null;
    }

    void setFab(String text, Runnable r) {
        fab.setText(text);
        fab.setOnClickListener(v -> r.run());
    }

    // ============================ Utilidades ============================
    JSONObject findKey(int id) {
        for (JSONObject k : keys) if (k.optInt("id") == id) return k;
        return null;
    }

    static int numVal(String s) {
        StringBuilder d = new StringBuilder();
        for (char ch : s.toCharArray()) { if (Character.isDigit(ch)) d.append(ch); else break; }
        try { return d.length() == 0 ? Integer.MAX_VALUE / 2 : Integer.parseInt(d.toString()); } catch (Exception e) { return Integer.MAX_VALUE / 2; }
    }

    static void sortKeys(List<JSONObject> l) {
        Collections.sort(l, (x, y) -> {
            int a = numVal(x.optString("num")), b = numVal(y.optString("num"));
            if (a != b) return Integer.compare(a, b);
            return x.optString("num").compareToIgnoreCase(y.optString("num"));
        });
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    TextView smallBtn(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 12, color));
        b.setPadding(dp(6), dp(9), dp(6), dp(9));
        b.setMaxLines(1);
        b.setOnClickListener(l);
        return b;
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    static void put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception e) { }
    }

    void pickDate(String iso, Cb cb) {
        Calendar c = Store.cal();
        try { c.setTime(Store.f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { }
        new DatePickerDialog(this, (dpk, y, m, d) -> cb.on(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void pickTime(String hm, Cb cb) {
        int h = 10, mi = 0;
        try { String[] x = hm.split(":"); h = Integer.parseInt(x[0]); mi = Integer.parseInt(x[1]); } catch (Exception e) { }
        new TimePickerDialog(this, (tp, hh, mm) -> cb.on(String.format(Locale.US, "%02d:%02d", hh, mm)), h, mi, false).show();
    }

    void afterRestore() {
        Store.scheduleAll(this);
        recreate();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

    View rangeCard(String from, String to, Cb onFrom, Cb onTo) {
        LinearLayout c = card();
        TextView f = field("📅  " + Store.shortDate(from) + " " + from.substring(0, 4));
        TextView t = field("📅  " + Store.shortDate(to) + " " + to.substring(0, 4));
        f.setOnClickListener(v -> pickDate(from, onFrom));
        t.setOnClickListener(v -> pickDate(to, onTo));
        c.addView(twoCols(labeled("Desde", f), labeled("Hasta", t)));
        return c;
    }
}
